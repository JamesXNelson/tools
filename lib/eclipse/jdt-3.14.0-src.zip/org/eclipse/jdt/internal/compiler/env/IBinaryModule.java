/*******************************************************************************
 * Copyright (c) 2017 GK Software AG, and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Stephan Herrmann - initial API and implementation
 *******************************************************************************/
package org.eclipse.jdt.internal.compiler.env;

/** Marker interface for usage of {@link org.eclipse.jdt.internal.compiler.classfmt.ModuleInfo} outside the compiler proper. */
public interface IBinaryModule extends IModule {
	// empty
}
